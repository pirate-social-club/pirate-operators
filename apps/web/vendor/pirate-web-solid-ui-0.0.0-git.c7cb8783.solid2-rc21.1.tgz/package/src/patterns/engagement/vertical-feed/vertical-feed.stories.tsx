import { omit } from "solid-js";
import { createSignal } from "solid-js";
import type { Meta, StoryObj } from "storybook-solidjs-vite";
import { expect, fn, userEvent, waitFor, within } from "storybook/test";

import { MobileFooterNav } from "@/patterns/navigation/mobile-footer-nav/mobile-footer-nav";
import { expectPhoneSheetClose } from "@/stories/lib/story-measure";
import { brokenPost, fixturePosts, longCaptionPost } from "./fixtures";
import { VerticalFeed, type VerticalFeedProps } from "./vertical-feed";

const meta = {
  title: "Patterns/Engagement/VerticalFeed",
  component: VerticalFeed,
  tags: ["autodocs"],
  args: {
    posts: fixturePosts,
    onActivePostChange: fn(),
    onEndReached: fn(),
    // No onLikeClick or onFollowClick: Paper draws no Like or Follow badge and
    // the app does not wire them, so the controls stay hidden here. The
    // LikeAndFollow story shows them for hosts that do pass the callbacks.
    onShareClick: fn(),
    onAuthorClick: fn(),
    onSoundtrackClick: fn(),
    onActivityClick: fn(),
    onMuteToggle: fn(),
    onViewed: fn(),
    onHaptic: fn(),
  },
  argTypes: {
    posts: { control: "object" },
    class: { table: { disable: true } },
    onActivePostChange: { table: { disable: true } },
    onEndReached: { table: { disable: true } },
    onLikeClick: { table: { disable: true } },
    onShareClick: { table: { disable: true } },
    onFollowClick: { table: { disable: true } },
    onAuthorClick: { table: { disable: true } },
    onSoundtrackClick: { table: { disable: true } },
    activities: { table: { disable: true } },
    moreActions: { table: { disable: true } },
    onActivityClick: { table: { disable: true } },
    onMuteToggle: { table: { disable: true } },
    onViewed: { table: { disable: true } },
    onHaptic: { table: { disable: true } },
  },
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component:
          "Full-screen, snap-scrolling vertical media feed (the TikTok-style pattern). Feed it plain MediaPostData; it autoplays the active post behind the browser's first-interaction gate, supports scroll and ArrowUp/ArrowDown navigation, and reports every intent (like, share, follow, author, soundtrack, mute, view, end-of-feed) through callbacks. Rail actions hide when their callback is absent. Mute is not in the rail: a More button (three dots, top right of the video) opens a menu on desktop and a bottom sheet on phone with Mute/Unmute and any host rows (moreActions), such as Report for community members. There is no Boost row: posts have no boost contract yet. Use it for immersive media browsing surfaces. Do not use it for mixed-content or text-heavy feeds, and do not expect it to route, notify, or fetch: the host app owns all side effects. Mobile overlay insets read the host-defined CSS variable --safe-area-bottom (typically set to env(safe-area-inset-bottom) plus any tab-bar offset); it falls back to 0px when the host does not define it.",
      },
    },
  },
} satisfies Meta<typeof VerticalFeed>;

export default meta;

type Story = StoryObj<typeof meta>;

/** Interactive wrapper that owns like state, like a host app would. */
function InteractiveFeed(props: VerticalFeedProps) {
  const [posts, setPosts] = createSignal<VerticalFeedProps["posts"]>(props.posts);
  const rest = omit(props, "posts", "onLikeClick");

  const handleLike = (postId: string) => {
    setPosts((current) =>
      current.map((post) =>
        post.id === postId && !("placeholder" in post)
          ? {
              ...post,
              isLiked: !post.isLiked,
              likeCount: post.isLiked ? post.likeCount - 1 : post.likeCount + 1,
            }
          : post,
      ),
    );
    props.onLikeClick?.(postId);
  };

  return (
    <VerticalFeed
      {...rest}
      posts={posts()}
      onLikeClick={props.onLikeClick ? handleLike : undefined}
    />
  );
}

export const Default: Story = {
  render: (args) => <InteractiveFeed {...args} />,
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    const region = canvas.getByRole("region", { name: "Media feed" });
    await expect(region).toBeVisible();
    await expect(canvas.getAllByText("@wavemaker").length).toBeGreaterThan(0);
    // Mute is not a rail action; it lives in the More menu.
    await expect(canvas.queryByRole("button", { name: /mute video/i })).toBeNull();

    // Paper's rail has no Like control and no Follow badge on the avatar.
    await expect(canvas.queryByRole("button", { name: /like video/i })).toBeNull();
    await expect(canvas.queryByRole("button", { name: /^Follow / })).toBeNull();

    // Keyboard navigation advances the active post.
    region.focus();
    await userEvent.keyboard("{ArrowDown}");
    await waitFor(() =>
      expect(args.onActivePostChange).toHaveBeenCalledWith("post-2", 1),
    );
    await userEvent.keyboard("{ArrowUp}");
    await waitFor(() =>
      expect(args.onActivePostChange).toHaveBeenCalledWith("post-1", 0),
    );
  },
};

/**
 * The optional Like control and Follow badge, which render only when the host
 * passes onLikeClick and onFollowClick. Paper does not draw them and the app
 * does not wire them today; this story keeps their callback coverage.
 */
export const LikeAndFollow: Story = {
  args: {
    onLikeClick: fn(),
    onFollowClick: fn(),
  },
  render: (args) => <InteractiveFeed {...args} />,
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    // Like toggles through the callback and updates the visible state.
    const likeButton = canvas.getAllByRole("button", { name: "Like video" })[0];
    await userEvent.click(likeButton);
    await expect(args.onLikeClick).toHaveBeenCalledWith("post-1");
    await waitFor(async () => {
      await expect(
        canvas.getAllByRole("button", { name: "Unlike video" })[0],
      ).toHaveAttribute("aria-pressed", "true");
    });

    await expect(
      canvas.getAllByRole("button", { name: "Follow wavemaker" })[0],
    ).toBeVisible();
  },
};

export const WithActivities: Story = {
  args: {
    activities: (postId) =>
      postId === "post-1"
        ? [
            { id: "study", label: "Study", icon: "speech" },
            { id: "karaoke", label: "Karaoke", icon: "microphone" },
          ]
        : undefined,
  },
  render: (args) => <InteractiveFeed {...args} />,
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);
    const karaoke = await canvas.findAllByRole("button", { name: "Karaoke" });
    await userEvent.click(karaoke[0]);
    await expect(args.onActivityClick).toHaveBeenCalledWith("post-1", "karaoke");
  },
};

export const Empty: Story = {
  args: {
    posts: [],
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getByText("No posts to show")).toBeVisible();
  },
};

export const Loading: Story = {
  args: {
    posts: fixturePosts.slice(0, 2),
    loading: true,
    hasMore: true,
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(
      canvas.getByRole("status", { name: "Loading more posts" }),
    ).toBeVisible();
  },
};

export const Error: Story = {
  args: {
    posts: [brokenPost],
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(await canvas.findByText("Playback error")).toBeVisible();
  },
};

export const LongContent: Story = {
  args: {
    posts: [longCaptionPost],
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    await expect(
      canvas.getAllByText(/deliberately long caption/)[0],
    ).toBeVisible();
  },
};

export const Mobile: Story = {
  args: {
    hasMobileFooter: true,
  },
  // Storybook 10 core viewport: mobile1 = Small mobile (320x568), provided by
  // MINIMAL_VIEWPORTS by default; no addon package required.
  globals: {
    viewport: { value: "mobile1", isRotated: false },
  },
  render: (args) => (
    <div class="relative">
      <InteractiveFeed {...args} />
      {/* The real four-tab footer the overlays must clear, as on the board. */}
      <MobileFooterNav
        activeItem="home"
        forceMobile
        onHomeClick={fn()}
        onProfileClick={fn()}
        onSongsClick={fn()}
        onWalletClick={fn()}
      />
    </div>
  ),
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const footer = canvas.getByRole("navigation", { name: "Primary navigation" });
    await expect(within(footer).getAllByRole("button")).toHaveLength(4);
    await expect(within(footer).getByRole("button", { name: "Home" })).toHaveAttribute("aria-current", "page");
    // The rail keeps its share control; there is no Follow badge.
    await expect(canvas.getAllByRole("button", { name: /share/i }).length).toBeGreaterThan(0);
    await expect(canvas.queryByRole("button", { name: /^Follow / })).toBeNull();
  },
};

const reportAction = fn();
const memberMoreActions: VerticalFeedProps["moreActions"] = (postId) =>
  postId === "post-1"
    ? [{ id: "report", label: "Report", onSelect: () => reportAction(postId) }]
    : undefined;

const moreTrigger = (canvasElement: HTMLElement, layout: "desktop" | "phone") => {
  const button = canvasElement.querySelector<HTMLButtonElement>(
    `[data-media-post="post-1"] [data-media-more="${layout}"] button`,
  );
  if (!button) throw new globalThis.Error(`${layout} More trigger not rendered`);
  return button;
};

/** Desktop More menu open under the three dots: Mute, then the host's Report. */
export const MoreMenuOpen: Story = {
  args: { moreActions: memberMoreActions },
  render: (args) => <InteractiveFeed {...args} />,
  play: async ({ canvasElement }) => {
    await userEvent.click(await waitFor(() => moreTrigger(canvasElement, "desktop")));
    const page = within(canvasElement.ownerDocument.body);
    const menu = await page.findByRole("menu");
    const items = within(menu).getAllByRole("menuitem");
    await expect(items.map((item) => item.textContent)).toEqual(["Mute", "Report"]);
  },
};

/** Choosing a More row: Mute toggles the audio, Report runs the host action once. */
export const MoreRunsActions: Story = {
  args: { moreActions: memberMoreActions },
  render: (args) => <InteractiveFeed {...args} />,
  play: async ({ canvasElement, args }) => {
    reportAction.mockClear();
    const page = within(canvasElement.ownerDocument.body);
    await userEvent.click(await waitFor(() => moreTrigger(canvasElement, "desktop")));
    await userEvent.click(await page.findByRole("menuitem", { name: "Mute" }));
    await expect(args.onMuteToggle).toHaveBeenCalledWith("post-1", true);
    await waitFor(() => expect(page.queryByRole("menu")).toBeNull());
    await userEvent.click(moreTrigger(canvasElement, "desktop"));
    await expect(await page.findByRole("menuitem", { name: "Unmute" })).toBeVisible();
    await userEvent.click(page.getByRole("menuitem", { name: "Report" }));
    await waitFor(() => expect(reportAction).toHaveBeenCalledTimes(1));
    await expect(reportAction).toHaveBeenCalledWith("post-1");
  },
};

/** Phone More sheet open: the handle, then Mute and the host's Report as rows. */
export const MobileMoreSheet: Story = {
  args: { moreActions: memberMoreActions, hasMobileFooter: true },
  globals: {
    viewport: { value: "mobile1", isRotated: false },
  },
  render: (args) => <InteractiveFeed {...args} />,
  play: async ({ canvasElement }) => {
    await userEvent.click(await waitFor(() => moreTrigger(canvasElement, "phone")));
    const page = within(canvasElement.ownerDocument.body);
    const sheet = await page.findByRole("dialog", { name: "More options" });
    const rows = [...sheet.querySelectorAll<HTMLButtonElement>("[data-media-more-row]")];
    await expect(rows.map((row) => row.textContent)).toEqual(["Mute", "Report"]);
    await expectPhoneSheetClose(sheet, rows[0]!);
  },
};
