import { fireEvent, screen, within } from "@testing-library/dom";
import { userEvent } from "@testing-library/user-event";
import { createSignal, flush, Show } from "solid-js";
import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

import { expectNoA11yViolations, render } from "@/test/test-utils";

import type { MediaPostData } from "./types";
import { VerticalFeed } from "./vertical-feed";

// jsdom leaves HTMLMediaElement playback unimplemented; stub it locally.
const playMock = vi.fn<() => Promise<void>>(() => Promise.resolve());
const pauseMock = vi.fn();
const loadMock = vi.fn();

beforeAll(() => {
  Object.defineProperty(HTMLMediaElement.prototype, "play", {
    configurable: true,
    writable: true,
    value: playMock,
  });
  Object.defineProperty(HTMLMediaElement.prototype, "pause", {
    configurable: true,
    writable: true,
    value: pauseMock,
  });
  Object.defineProperty(HTMLMediaElement.prototype, "load", {
    configurable: true,
    writable: true,
    value: loadMock,
  });
});

beforeEach(() => {
  playMock.mockClear();
  pauseMock.mockClear();
  loadMock.mockClear();
});

const testPosts: MediaPostData[] = [
  {
    id: "post-1",
    videoUrl: "/clip-1.mp4",
    posterUrl: "/poster-1.jpg",
    authorName: "wavemaker",
    caption: "First post.",
    title: "Neon Skyline",
    artist: "Glass Avenue",
    likeCount: 1234,
    isLiked: false,
    isFollowing: false,
  },
  {
    id: "post-2",
    videoUrl: "/clip-2.mp4",
    posterUrl: "/poster-2.jpg",
    authorName: "nightowl",
    caption: "Second post.",
    likeCount: 5678,
    isLiked: true,
    isFollowing: false,
  },
  {
    id: "post-3",
    videoUrl: "/clip-3.mp4",
    posterUrl: "/poster-3.jpg",
    authorName: "stargazer",
    caption: "Third post.",
    likeCount: 12400,
    isLiked: false,
    isFollowing: true,
  },
];

function phoneMoreButton(container: HTMLElement, postId: string): HTMLButtonElement {
  const button = container.querySelector<HTMLButtonElement>(
    `[data-media-post="${postId}"] [data-media-more="phone"] button`,
  );
  if (!button) throw new Error(`no phone More button for ${postId}`);
  return button;
}

function pressArrow(key: "ArrowDown" | "ArrowUp") {
  const region = screen.getByRole("region", { name: "Media feed" });
  fireEvent.keyDown(region, { key });
  flush();
}

describe("VerticalFeed", () => {
  it("renders every post with author, caption, and formatted like count", () => {
    const container = render(() => (
      <VerticalFeed posts={testPosts} onLikeClick={vi.fn()} />
    ));
    flush();

    const view = within(container);
    expect(view.getAllByText("@wavemaker").length).toBeGreaterThan(0);
    expect(view.getAllByText("@nightowl").length).toBeGreaterThan(0);
    expect(view.getAllByText("@stargazer").length).toBeGreaterThan(0);
    expect(view.getAllByText("1.2K").length).toBeGreaterThan(0);
    expect(view.getAllByRole("button", { name: "Like video" })).toHaveLength(4);
  });

  it("hides action buttons whose callbacks are absent; mute is not a rail action", () => {
    const container = render(() => (
      <VerticalFeed posts={testPosts} onLikeClick={vi.fn()} />
    ));
    flush();

    const view = within(container);
    // Wired: like stays. Unwired: share, follow, author, soundtrack hide.
    expect(view.getAllByRole("button", { name: "Like video" })).toHaveLength(4);
    expect(
      view.queryByRole("button", { name: "Share video" }),
    ).not.toBeInTheDocument();
    expect(
      view.queryByRole("button", { name: /Follow / }),
    ).not.toBeInTheDocument();
    expect(
      view.queryByRole("button", { name: /'s profile/ }),
    ).not.toBeInTheDocument();
    expect(
      view.queryByRole("button", { name: /^Open / }),
    ).not.toBeInTheDocument();
    // Mute moved from the rail into each post's More menu (phone + desktop).
    expect(view.queryByRole("button", { name: /mute video/i })).not.toBeInTheDocument();
    expect(view.getAllByRole("button", { name: "More options" })).toHaveLength(6);
    // Author and soundtrack lines degrade to non-interactive text.
    expect(view.getAllByText("@wavemaker").length).toBeGreaterThan(0);
    expect(view.getAllByText(/Neon Skyline/).length).toBeGreaterThan(0);
  });

  it("emits onActivePostChange for the first post on mount", () => {
    const onActivePostChange = vi.fn();
    render(() => (
      <VerticalFeed posts={testPosts} onActivePostChange={onActivePostChange} />
    ));
    flush();

    expect(onActivePostChange).toHaveBeenCalledWith("post-1", 0);
  });

  it("changes the active post with ArrowDown and ArrowUp", () => {
    const onActivePostChange = vi.fn();
    render(() => (
      <VerticalFeed posts={testPosts} onActivePostChange={onActivePostChange} />
    ));
    flush();

    pressArrow("ArrowDown");
    expect(onActivePostChange).toHaveBeenCalledWith("post-2", 1);

    pressArrow("ArrowDown");
    expect(onActivePostChange).toHaveBeenCalledWith("post-3", 2);

    pressArrow("ArrowUp");
    expect(onActivePostChange).toHaveBeenCalledWith("post-2", 1);
  });

  it("does not navigate past the first or last post", () => {
    const onActivePostChange = vi.fn();
    render(() => (
      <VerticalFeed posts={testPosts} onActivePostChange={onActivePostChange} />
    ));
    flush();
    onActivePostChange.mockClear();

    pressArrow("ArrowUp");
    expect(onActivePostChange).not.toHaveBeenCalled();
  });

  it("emits onEndReached when the active post nears the end", () => {
    const onEndReached = vi.fn();
    render(() => (
      <VerticalFeed posts={testPosts} hasMore onEndReached={onEndReached} />
    ));
    flush();

    pressArrow("ArrowDown");
    expect(onEndReached).toHaveBeenCalledTimes(1);
  });

  it("emits like, share, follow, and author callbacks with the post id", async () => {
    const user = userEvent.setup();
    const onLikeClick = vi.fn();
    const onShareClick = vi.fn();
    const onFollowClick = vi.fn();
    const onAuthorClick = vi.fn();
    const container = render(() => (
      <VerticalFeed
        posts={testPosts}
        onLikeClick={onLikeClick}
        onShareClick={onShareClick}
        onFollowClick={onFollowClick}
        onAuthorClick={onAuthorClick}
      />
    ));
    flush();

    const view = within(container);
    await user.click(view.getAllByRole("button", { name: "Like video" })[0]);
    expect(onLikeClick).toHaveBeenCalledWith("post-1");

    await user.click(view.getAllByRole("button", { name: "Share video" })[0]);
    expect(onShareClick).toHaveBeenCalledWith("post-1");

    await user.click(
      view.getAllByRole("button", { name: "Follow wavemaker" })[0],
    );
    expect(onFollowClick).toHaveBeenCalledWith("post-1");

    await user.click(
      view.getAllByRole("button", { name: "View wavemaker's profile" })[0],
    );
    expect(onAuthorClick).toHaveBeenCalledWith("post-1");
  });

  it("shows host activities only on the posts that offer them and reports the pick", async () => {
    const user = userEvent.setup();
    const onActivityClick = vi.fn();
    const container = render(() => (
      <VerticalFeed
        posts={testPosts}
        activities={(postId) =>
          postId === "post-1"
            ? [
                { id: "study", label: "Study", icon: "speech" },
                { id: "karaoke", label: "Karaoke", icon: "microphone" },
              ]
            : undefined
        }
        onActivityClick={onActivityClick}
      />
    ));
    flush();

    const view = within(container);
    // Mobile and desktop rails both render, so each activity appears twice.
    expect(view.getAllByRole("button", { name: "Study" })).toHaveLength(2);
    expect(view.getAllByRole("button", { name: "Karaoke" })).toHaveLength(2);
    const second = container.querySelector('[data-media-post="post-2"]')!;
    expect(second.querySelector("[data-media-activity]")).toBeNull();

    await user.click(view.getAllByRole("button", { name: "Karaoke" })[0]);
    expect(onActivityClick).toHaveBeenCalledWith("post-1", "karaoke");
    await user.click(view.getAllByRole("button", { name: "Study" })[0]);
    expect(onActivityClick).toHaveBeenCalledWith("post-1", "study");
  });

  it("keeps playback gated until the first user interaction", async () => {
    const user = userEvent.setup();
    const container = render(() => <VerticalFeed posts={testPosts} />);
    flush();

    // No autoplay attempt before interaction, even for the active post.
    expect(playMock).not.toHaveBeenCalled();

    const playButtons = within(container).getAllByRole("button", {
      name: "Play video",
    });
    expect(playButtons.length).toBeGreaterThan(0);

    await user.click(playButtons[0]);
    flush();

    expect(playMock).toHaveBeenCalled();
    expect(
      within(container).getAllByRole("button", { name: "Pause video" })[0],
    ).toBeInTheDocument();
  });

  it("emits onMuteToggle from the More sheet's Mute row with the post id", async () => {
    const user = userEvent.setup();
    const onMuteToggle = vi.fn();
    const container = render(() => (
      <VerticalFeed posts={testPosts} onMuteToggle={onMuteToggle} />
    ));
    flush();

    await user.click(phoneMoreButton(container, "post-1"));
    flush();
    const sheet = await screen.findByRole("dialog", { name: "More options" });
    await user.click(within(sheet).getByRole("button", { name: "Mute" }));
    flush();
    expect(onMuteToggle).toHaveBeenCalledWith("post-1", true);
    expect(container.querySelector("video")?.muted).toBe(true);
  });

  it("labels the More row Unmute under controlled mute and toggles it back", async () => {
    const user = userEvent.setup();
    const onMuteToggle = vi.fn();
    const container = render(() => (
      <VerticalFeed posts={testPosts} muted onMuteToggle={onMuteToggle} />
    ));
    flush();
    expect(container.querySelector("video")?.muted).toBe(true);

    await user.click(phoneMoreButton(container, "post-1"));
    flush();
    const sheet = await screen.findByRole("dialog", { name: "More options" });
    const rows = [...sheet.querySelectorAll<HTMLButtonElement>("[data-media-more-row]")];
    expect(rows.map((row) => row.textContent)).toEqual(["Unmute"]);
    // The sheet keeps its visible close beside the rows.
    expect(within(sheet).getByRole("button", { name: "Close" })).toBeTruthy();
    await user.click(rows[0]!);
    flush();
    expect(onMuteToggle).toHaveBeenCalledWith("post-1", false);
  });

  it("lists host More actions after Mute and runs the chosen one once", async () => {
    const user = userEvent.setup();
    const onReport = vi.fn();
    const container = render(() => (
      <VerticalFeed
        posts={testPosts}
        moreActions={(postId) =>
          postId === "post-1" ? [{ id: "report", label: "Report", onSelect: onReport }] : undefined
        }
      />
    ));
    flush();

    await user.click(phoneMoreButton(container, "post-1"));
    flush();
    const sheet = await screen.findByRole("dialog", { name: "More options" });
    expect([...sheet.querySelectorAll<HTMLButtonElement>("[data-media-more-row]")].map((row) => row.textContent)).toEqual(["Mute", "Report"]);
    await user.click(within(sheet).getByRole("button", { name: "Report" }));
    flush();
    await vi.waitFor(() => expect(onReport).toHaveBeenCalledTimes(1));
  });

  it("opens the desktop More menu with Mute and host rows as menu items", async () => {
    const user = userEvent.setup();
    const onMuteToggle = vi.fn();
    const container = render(() => (
      <VerticalFeed
        posts={testPosts.slice(0, 1)}
        onMuteToggle={onMuteToggle}
        moreActions={() => [{ id: "report", label: "Report", onSelect: vi.fn() }]}
      />
    ));
    flush();

    const trigger = container.querySelector<HTMLButtonElement>('[data-media-more="desktop"] button');
    if (!trigger) throw new Error("no desktop More trigger");
    await user.click(trigger);
    flush();
    const menu = await screen.findByRole("menu");
    expect(within(menu).getAllByRole("menuitem").map((item) => item.textContent)).toEqual(["Mute", "Report"]);
    await user.click(within(menu).getByRole("menuitem", { name: "Mute" }));
    flush();
    expect(onMuteToggle).toHaveBeenCalledWith("post-1", true);
  });

  it("runs a desktop menu host action once after the menu closes", async () => {
    const user = userEvent.setup();
    const onReport = vi.fn();
    const container = render(() => (
      <VerticalFeed
        posts={testPosts.slice(0, 1)}
        moreActions={() => [{ id: "report", label: "Report", onSelect: onReport }]}
      />
    ));
    flush();

    const trigger = container.querySelector<HTMLButtonElement>('[data-media-more="desktop"] button');
    if (!trigger) throw new Error("no desktop More trigger");
    await user.click(trigger);
    flush();
    await user.click(await screen.findByRole("menuitem", { name: "Report" }));
    flush();
    await vi.waitFor(() => expect(onReport).toHaveBeenCalledTimes(1));
    expect(screen.queryByRole("menu")).toBeNull();
  });

  it("keeps phone Mute reachable below the host header when the header owns the top right", async () => {
    const user = userEvent.setup();
    const onMuteToggle = vi.fn();
    const container = render(() => (
      <VerticalFeed posts={testPosts.slice(0, 1)} muted mobileMoreBelowHeader onMuteToggle={onMuteToggle} />
    ));
    flush();
    const phone = container.querySelector<HTMLElement>('[data-media-more="phone"]');
    if (!phone) throw new Error("no phone More");
    expect(phone.style.top).toContain("4rem");
    expect(container.querySelector('[data-media-more="desktop"] button')).not.toBeNull();

    const trigger = phone.querySelector<HTMLButtonElement>("button");
    if (!trigger) throw new Error("no phone More trigger");
    await user.click(trigger);
    flush();
    await user.click(await screen.findByRole("button", { name: "Unmute" }));
    flush();
    expect(onMuteToggle).toHaveBeenCalledWith(testPosts[0]?.id, false);
  });

  it("reports an implicit unmute when play is pressed on controlled muted media", async () => {
    const user = userEvent.setup();
    const onMuteToggle = vi.fn();
    const [muted, setMuted] = createSignal(true);
    const container = render(() => (
      <VerticalFeed
        posts={testPosts}
        muted={muted()}
        onMuteToggle={(id, nextMuted) => {
          onMuteToggle(id, nextMuted);
          setMuted(nextMuted);
        }}
      />
    ));
    flush();

    const activeVideo = container.querySelector("video")!;
    fireEvent(activeVideo, new Event("loadedmetadata"));
    flush();
    await user.click(
      within(container).getAllByRole("button", { name: "Play video" })[0],
    );
    flush();

    expect(onMuteToggle).toHaveBeenCalledWith("post-1", false);
    expect(container.querySelector("video")?.muted).toBe(false);
  });

  it("pauses an active post while a host panel is open", async () => {
    const user = userEvent.setup();
    const [pausedPostId, setPausedPostId] = createSignal<string>();
    const container = render(() => (
      <VerticalFeed posts={testPosts} pausedPostId={pausedPostId()} />
    ));
    flush();

    const activeVideo = container.querySelector("video")!;
    fireEvent(activeVideo, new Event("loadedmetadata"));
    flush();
    await user.click(
      within(container).getAllByRole("button", { name: "Play video" })[0],
    );
    flush();
    expect(
      within(container).getAllByRole("button", { name: "Pause video" })[0],
    ).toBeInTheDocument();

    Object.defineProperty(activeVideo, "paused", {
      configurable: true,
      value: false,
    });
    const pauseCallsBefore = pauseMock.mock.calls.length;
    setPausedPostId("post-1");
    flush();
    expect(pauseMock.mock.calls.length).toBeGreaterThan(pauseCallsBefore);
    expect(
      within(container).getAllByRole("button", { name: "Play video" })[0],
    ).toBeInTheDocument();
  });

  it("emits onViewed once after three seconds of cumulative watch time", async () => {
    const user = userEvent.setup();
    const onViewed = vi.fn();
    const container = render(() => (
      <VerticalFeed posts={testPosts} onViewed={onViewed} />
    ));
    flush();

    await user.click(
      within(container).getAllByRole("button", { name: "Play video" })[0],
    );
    flush();

    const video = container.querySelector("video")!;
    for (const time of [0.5, 1, 1.5, 2, 2.5, 3]) {
      Object.defineProperty(video, "currentTime", {
        configurable: true,
        value: time,
      });
      fireEvent(video, new Event("timeupdate"));
    }

    expect(onViewed).toHaveBeenCalledTimes(1);
    expect(onViewed).toHaveBeenCalledWith("post-1");
  });

  it("reports playback progress for the media post that emitted it", () => {
    const onTimeUpdate = vi.fn();
    const container = render(() => (
      <VerticalFeed posts={testPosts} onTimeUpdate={onTimeUpdate} />
    ));
    flush();

    const video = container.querySelector("video")!;
    Object.defineProperties(video, {
      currentTime: { configurable: true, value: 12.5 },
      duration: { configurable: true, value: 40 },
    });
    fireEvent(video, new Event("timeupdate"));

    expect(onTimeUpdate).toHaveBeenCalledWith("post-1", 12.5, 40);
  });

  it("can hide shared media chrome for a product-owned overlay", () => {
    const container = render(() => (
      <VerticalFeed posts={testPosts.slice(0, 1)} showChrome={false} />
    ));
    flush();

    expect(container.querySelector("video")).toBeInTheDocument();
    expect(within(container).queryByText("@wavemaker")).not.toBeInTheDocument();
    expect(
      within(container).queryByRole("button", { name: "Like" }),
    ).not.toBeInTheDocument();
  });

  it("renders the empty state when there are no posts", () => {
    render(() => <VerticalFeed posts={[]} />);
    flush();

    expect(screen.getByText("No posts to show")).toBeVisible();
  });

  it("shows a loading row while more posts load", () => {
    render(() => <VerticalFeed posts={testPosts.slice(0, 1)} loading hasMore />);
    flush();

    expect(
      screen.getByRole("status", { name: "Loading more posts" }),
    ).toBeInTheDocument();
  });

  it("has no axe violations", async () => {
    render(() => <VerticalFeed posts={testPosts} />);
    flush();

    await expectNoA11yViolations();
  });
});

describe("host placeholder playback policy", () => {
  it("exposes the active row, autoplay policy, interaction gate and controlled mute", async () => {
    type Placeholder = {
      readonly id: string;
      readonly active: () => boolean;
      readonly autoplay: () => boolean;
      readonly hasUserInteracted: () => boolean;
      readonly markUserInteracted: () => void;
      readonly muted: () => boolean | undefined;
      readonly reportMuteToggle: (muted: boolean) => void;
    };
    const seen: Placeholder[] = [];
    const onMuteToggle = vi.fn();
    render(() => (
      <VerticalFeed
        autoplay
        feedLabel="Policy feed"
        muted
        onMuteToggle={onMuteToggle}
        posts={[{ id: "host-1", placeholder: true }, { id: "host-2", placeholder: true }]}
        renderPlaceholder={(id, context) => {
          seen.push({ id, ...context });
          return (
            <button type="button" onClick={() => context.markUserInteracted()}>
              play {id}
            </button>
          );
        }}
      />
    ));
    await flush();

    const region = screen.getByRole("region", { name: "Policy feed" });
    expect(seen.map(entry => entry.id)).toEqual(["host-1", "host-2"]);
    expect(seen[0]!.active()).toBe(true);
    expect(seen[1]!.active()).toBe(false);
    expect(seen[0]!.autoplay()).toBe(true);
    expect(seen[1]!.autoplay()).toBe(false);
    expect(seen[0]!.hasUserInteracted()).toBe(false);
    expect(seen[0]!.muted()).toBe(true);

    // Arrow navigation moves the active row: the policy follows.
    fireEvent.keyDown(region, { key: "ArrowDown" });
    await flush();
    expect(seen[1]!.active()).toBe(true);
    expect(seen[1]!.autoplay()).toBe(true);
    expect(seen[0]!.autoplay()).toBe(false);

    // The gate flips through a user event, exactly as the host player reports it.
    await userEvent.click(screen.getByRole("button", { name: "play host-1" }));
    expect(seen[0]!.hasUserInteracted()).toBe(true);
    expect(seen[1]!.hasUserInteracted()).toBe(true);

    seen[1]!.reportMuteToggle(false);
    expect(onMuteToggle).toHaveBeenCalledWith("host-2", false);
  });
});

describe("host-attached video sources", () => {
  const streamed: MediaPostData = {
    id: "post-streamed",
    posterUrl: "/poster-streamed.jpg",
    authorName: "streamer",
    caption: "Signed playback.",
    likeCount: 1,
  };

  it("attaches once to the active post's own video element, keeps it across a refresh, and releases it on unmount", async () => {
    const attach = vi.fn<(video: HTMLVideoElement) => () => void>();
    const release = vi.fn();
    attach.mockReturnValue(release);
    const attacher = (video: HTMLVideoElement) => attach(video);
    const [posts, setPosts] = createSignal<MediaPostData[]>([streamed]);
    const [shown, setShown] = createSignal(true);
    const container = render(() => (
      <Show when={shown()}>
        <VerticalFeed posts={posts()} attachVideo={() => attacher} />
      </Show>
    ));
    flush();
    await vi.waitFor(() => expect(attach).toHaveBeenCalledTimes(1));
    expect(attach.mock.calls[0]?.[0]).toBe(container.querySelector("video"));

    // A host refresh hands over new row objects with the same attacher.
    setPosts([{ ...streamed }]);
    flush();
    await new Promise((resolve) => setTimeout(resolve, 10));
    expect(attach).toHaveBeenCalledTimes(1);
    expect(release).not.toHaveBeenCalled();

    setShown(false);
    flush();
    await vi.waitFor(() => expect(release).toHaveBeenCalledTimes(1));
  });

  it("a post with a direct videoUrl ignores the host attacher", async () => {
    const attach = vi.fn(() => () => {});
    render(() => <VerticalFeed posts={testPosts} attachVideo={() => attach} />);
    flush();
    await new Promise((resolve) => setTimeout(resolve, 10));
    expect(attach).not.toHaveBeenCalled();
  });
});
