import type { Meta, StoryObj } from "storybook-solidjs-vite";
import { expect, waitFor, within } from "storybook/test";

import { demoArtworkImage } from "@/stories/lib/fixtures";
import { StoryRow } from "@/stories/lib/story-layout";
import { CommunityAvatar } from "./community-avatar";

const meta = {
  title: "Patterns/Engagement/CommunityAvatar",
  component: CommunityAvatar,
  tags: ["autodocs"],
  args: {
    communityId: "cmt_atlas",
    displayName: "Atlas Gardens",
    size: "md",
  },
  argTypes: {
    size: {
      control: "select",
      options: ["xs", "sm", "md", "lg"],
    },
  },
  parameters: {
    docs: {
      description: {
        component:
          "Community identity avatar. Resolves an explicit `avatarSrc`, or uses a deterministic HTML/CSS identity mark derived from the stable community inputs.",
      },
    },
  },
} satisfies Meta<typeof CommunityAvatar>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const avatar = canvas.getByRole("img", { name: "Atlas Gardens" });
    await expect(avatar).toBeVisible();
  },
};

export const Sizes: Story = {
  render: () => (
    <StoryRow class="items-end">
      <CommunityAvatar
        communityId="cmt_tide"
        displayName="Tide Room"
        size="xs"
      />
      <CommunityAvatar
        communityId="cmt_atlas"
        displayName="Atlas Gardens"
        size="sm"
      />
      <CommunityAvatar
        communityId="cmt_signal"
        displayName="Signal Room"
        size="md"
      />
      <CommunityAvatar
        communityId="cmt_foundry"
        displayName="Foundry Operators"
        size="lg"
      />
    </StoryRow>
  ),
  play: async ({ canvasElement }) => {
    // Paper PostCard: the 24px avatar carries 9px initials.
    const xs = within(canvasElement).getByRole("img", { name: "Tide Room" });
    const initials = xs.querySelector("span[aria-hidden]");
    if (!initials) throw new Error("no initials");
    await expect(getComputedStyle(initials).fontSize).toBe("9px");
  },
};

export const Variants: Story = {
  render: () => (
    <StoryRow class="items-end">
      <CommunityAvatar
        avatarSrc={demoArtworkImage}
        communityId="cmt_atlas"
        displayName="Atlas Gardens"
        size="md"
      />
      <CommunityAvatar
        communityId="cmt_atlas"
        displayName="Atlas Gardens"
        size="md"
      />
    </StoryRow>
  ),
  play: async ({ canvasElement }) => {
    // The image variant loads its fixture instead of falling back to initials.
    const image = canvasElement.querySelector("img");
    await expect(image).not.toBeNull();
    await waitFor(() =>
      expect((image as HTMLImageElement).complete && (image as HTMLImageElement).naturalWidth > 0).toBe(true),
    );
  },
};
